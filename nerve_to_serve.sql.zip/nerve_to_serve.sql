--
-- Database: `nerve_to_serve`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_summary`
--
-- Creation: Oct 13, 2016 at 03:56 AM
--

CREATE TABLE `account_summary` (
  `transaction_id` bigint(15) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `first_name` varchar(15) NOT NULL,
  `last_name` varchar(15) NOT NULL,
  `amount` bigint(15) NOT NULL,
  `day` int(2) NOT NULL,
  `month` varchar(9) NOT NULL,
  `year` int(4) NOT NULL,
  `time1` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='account_summary';

--
-- RELATIONS FOR TABLE `account_summary`:
--

--
-- Dumping data for table `account_summary`
--

INSERT INTO `account_summary` (`transaction_id`, `email_id`, `first_name`, `last_name`, `amount`, `day`, `month`, `year`, `time1`) VALUES
(1, 'arun@charity.com', 'arun', 'pandian', 15000, 7, 'october', 2014, '08:12am'),
(2, 'arun@charity.com', 'arun', 'pandian', 25000, 13, 'june', 2015, '01:30pm'),
(3, 'arun@charity.com', 'arun', 'pandian', 65000, 15, 'july', 2016, '11:00am'),
(4, 'raj@charity.com', 'raj', 'kumar', 25000, 5, 'april', 2015, '03:30pm'),
(5, 'raj@charity.com', 'raj', 'kumar', 25000, 24, 'march', 2016, '06:30pm'),
(6, 'arun@charity.com', 'arun', 'pandian', 45000, 25, 'june', 2016, '09:50pm'),
(7, 'arun@charity.com', 'arun', 'pandian', 100000, 1, 'january', 2015, '09:10am'),
(8, 'arun@charity.com', 'arun', 'pandian', 15000, 5, 'october', 2013, '10:30am'),
(9, 'raj@charity.com', 'raj', 'kumar', 12000, 3, 'april', 2014, '07:13am'),
(10, 'arun@charity.com', 'arun', 'pandian', 450000, 6, 'october', 2017, '09:10am'),
(11, 'arun@charity.com', 'arun', 'pandian', 45000, 1, 'january', 2014, '09:10am'),
(12, 'raj@charity.com', 'raj', 'kumar', 98000, 2, 'march', 2017, '09:56am'),
(13, 'raj@charity.com', 'raj', 'kumar', 80000, 4, 'april', 2017, '10:30am'),
(14, 'raj@charity.com', 'raj', 'kumar', 100, 6, 'october', 2018, '07:45am'),
(15, 'raj@charity.com', 'raj', 'kumar', 100, 6, 'october', 2018, '07:45am'),
(16, 'raj@charity.com', 'raj', 'kumar', 100, 6, 'october', 2018, '07:45am'),
(17, 'raj@charity.com', 'raj', 'kumar', 100, 6, 'october', 2018, '07:45am'),
(18, 'raj@charity.com', 'raj', 'kumar', 100, 6, 'october', 2018, '07:45am'),
(19, 'raj@charity.com', 'raj', 'kumar', 100, 6, 'october', 2018, '07:45am'),
(20, 'raj@charity.com', 'raj', 'kumar', 100, 6, 'october', 2018, '07:45am'),
(21, 'raj@charity.com', 'raj', 'kumar', 100, 6, 'october', 2018, '07:45am'),
(22, 'raj@charity.com', 'raj', 'kumar', 100, 6, 'october', 2018, '07:45am'),
(23, 'raj@charity.com', 'raj', 'kumar', 100, 6, 'october', 2018, '07:45am'),
(24, 'raj@charity.com', 'raj', 'kumar', 100, 7, 'november', 2016, '05:00pm'),
(25, 'raj@charity.com', 'raj', 'kumar', 100, 1, 'january', 2017, '11:30am'),
(26, 'arun@charity.com', 'arun', 'pandian', 150, 1, 'january', 2016, '08:50am'),
(27, 'kutty@charity.com', 'sri', 'kutty', 1000, 1, 'january', 2016, '08:50am'),
(28, 'bhrgav@mail.com', 'bhar', 'a', 25000, 14, 'october', 2016, '01:50pm');

-- --------------------------------------------------------

--
-- Table structure for table `current_fund_amount`
--
-- Creation: Oct 11, 2016 at 05:32 AM
--

CREATE TABLE `current_fund_amount` (
  `id` int(1) NOT NULL,
  `current_fund_amount` bigint(15) NOT NULL,
  `day` int(2) NOT NULL,
  `month` varchar(9) NOT NULL,
  `year` int(4) NOT NULL,
  `time1` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='current_fund_amount';

--
-- RELATIONS FOR TABLE `current_fund_amount`:
--

--
-- Dumping data for table `current_fund_amount`
--

INSERT INTO `current_fund_amount` (`id`, `current_fund_amount`, `day`, `month`, `year`, `time1`) VALUES
(1, 600650, 14, 'october', 2016, '01:50pm');

-- --------------------------------------------------------

--
-- Table structure for table `expendicture_entry`
--
-- Creation: Oct 13, 2016 at 03:59 AM
--

CREATE TABLE `expendicture_entry` (
  `expendicture_id` bigint(15) NOT NULL,
  `day` int(2) NOT NULL,
  `month` varchar(8) NOT NULL,
  `year` int(4) NOT NULL,
  `time1` varchar(7) NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount_spend` bigint(15) NOT NULL,
  `spend_to_shop` varchar(255) NOT NULL,
  `current_fund_before` bigint(15) NOT NULL,
  `current_fund_after` bigint(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='expendicture_entry';

--
-- RELATIONS FOR TABLE `expendicture_entry`:
--

--
-- Dumping data for table `expendicture_entry`
--

INSERT INTO `expendicture_entry` (`expendicture_id`, `day`, `month`, `year`, `time1`, `description`, `amount_spend`, `spend_to_shop`, `current_fund_before`, `current_fund_after`) VALUES
(1, 10, 'march', 2016, '01:00pm', 'lunch for 30 children', 500, 'hotel karuna', 575150, 575650),
(2, 15, 'march', 2016, '09:10am', 'breakfast for 50 children', 10000, 'hotel', 585000, 575000);

-- --------------------------------------------------------

--
-- Table structure for table `login_details`
--
-- Creation: Oct 11, 2016 at 03:39 AM
--

CREATE TABLE `login_details` (
  `email_id` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `access_type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='login_account_detail';

--
-- RELATIONS FOR TABLE `login_details`:
--

--
-- Dumping data for table `login_details`
--

INSERT INTO `login_details` (`email_id`, `password`, `access_type`) VALUES
('admin@nerve.com', '1234', 'administrator'),
('arun@charity.com', '1234', 'administrator'),
('bhar@mail.com', '1234', 'visitor'),
('raj@charity.com', '1234', 'visitor'),
('raja@nerve.com', '1234', 'administrator'),
('visitor@nerve.com', '1234', 'visitor');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_feedback`
--
-- Creation: Oct 12, 2016 at 04:19 PM
--

CREATE TABLE `visitor_feedback` (
  `name` varchar(30) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `subject` varchar(80) NOT NULL,
  `comment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='visitor feedback';

--
-- RELATIONS FOR TABLE `visitor_feedback`:
--

--
-- Dumping data for table `visitor_feedback`
--

INSERT INTO `visitor_feedback` (`name`, `email_id`, `subject`, `comment`) VALUES
('arun', 'arunpandian@gmail.com', 'hai', 'hello'),
('tamil', 'tamil@gmail.com', 'sample', 'u r doing great job'),
('123', 'ddtryy', 'dtry', 'edygf'),
('bhar', 'bhar@mail.com', 'demo', 'hai'),
('vivek', 'vivek@gmail.com', 'hello', 'hai'),
('arun', 'gte', 'hyrd', 'htdt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_summary`
--
ALTER TABLE `account_summary`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `expendicture_entry`
--
ALTER TABLE `expendicture_entry`
  ADD PRIMARY KEY (`expendicture_id`);

--
-- Indexes for table `login_details`
--
ALTER TABLE `login_details`
  ADD PRIMARY KEY (`email_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_summary`
--
ALTER TABLE `account_summary`
  MODIFY `transaction_id` bigint(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `expendicture_entry`
--
ALTER TABLE `expendicture_entry`
  MODIFY `expendicture_id` bigint(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Metadata
--
USE `phpmyadmin`;

--
-- Metadata for account_summary
--

--
-- Metadata for current_fund_amount
--

--
-- Metadata for expendicture_entry
--

--
-- Metadata for login_details
--

--
-- Metadata for visitor_feedback
--

--
-- Metadata for nerve_to_serve
--
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
